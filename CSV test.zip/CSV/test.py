import pandas as pd
import math


df = pd.read_csv('activity_data.csv')


max_value = df['TotalActiveMinutes'].max()
min_value = df['TotalActiveMinutes'].min()
average = df['TotalActiveMinutes'].mean()

razlika = abs((average-max_value)/(average+max_value))* 100
for value in df['TotalActiveMinutes']:
    normalizacija = max_value / value
#Pokusao sam 

print(f'Maximum value for this column is : {max_value}')
print(f'Minimum value for this column is: {min_value}')

print(f'Average value for this column is:{average.__round__()}')
print(f'Razlika je : {razlika.__round__()}')

